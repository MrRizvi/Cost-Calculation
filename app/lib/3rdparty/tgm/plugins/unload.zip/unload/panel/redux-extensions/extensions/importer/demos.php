<?php

$demosArray = array(
	array(
		'name'    => esc_html__( 'Main', 'unload' ),
		'src'     => PLUGIN_URI . 'panel/redux-extensions/extensions/importer/assets/demo/main.jpg',
		'uri'     => 'http://webinane.com/demoData/unload/demo.zip',
		'preview' => 'http://themes.webinane.com/wp/unload',
	)
);
