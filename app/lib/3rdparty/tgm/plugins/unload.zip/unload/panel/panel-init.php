<?php

// Load the embedded Redux Framework
$panel = Plugin_ROOT . 'panel';
if ( file_exists( $panel . '/redux-framework/framework.php' ) ) {

	include $panel . '/redux-framework/framework.php';
}

// Load the theme/plugin options
if ( file_exists( $panel . '/options-init.php' ) ) {
	include $panel . '/options-init.php';
}

// Load Redux extensions
if ( file_exists( $panel . '/redux-extensions/extensions-init.php' ) ) {
	include $panel . '/redux-extensions/extensions-init.php';
}